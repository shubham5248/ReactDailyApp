import React,{Component} from "react";
export default class UserRead extends Component{
    state={

    }
    render(){
        return(
            <>
            </>
        )
    }
}